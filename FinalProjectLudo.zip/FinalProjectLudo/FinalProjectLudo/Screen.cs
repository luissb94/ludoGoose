﻿using System;

namespace FinalProjectLudo
{
    class Screen
    {
        protected Hardware hardware;

        public Screen(Hardware hardware)
        {
            this.hardware = hardware;
        }
        
    }
}
